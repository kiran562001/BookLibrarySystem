package com.cjc.model;
	import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
	import javax.persistence.*;
	import java.util.HashSet;
	import java.util.Set;
	import javax.persistence.*;
	import java.util.HashSet;
	import java.util.Set;

	@Entity
	@Data
	public class Library {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String libraryName;

	    @ManyToMany(cascade = { CascadeType.ALL })
	    @JoinTable(
	        name = "library_book",
	        joinColumns = { @JoinColumn(name = "library_id") },
	        inverseJoinColumns = { @JoinColumn(name = "book_id") }
	    )
	    private Set<Book> books = new HashSet<>();

	    // Constructors, getters, setters, and toString method
	    // Omitted for brevity
	}
