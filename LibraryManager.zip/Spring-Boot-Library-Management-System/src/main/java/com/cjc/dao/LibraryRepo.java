package com.cjc.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.model.Book;
import com.cjc.model.Library;

@Repository
public interface LibraryRepo extends JpaRepository<Library, Long> {
	public interface BookRepository extends JpaRepository<Book, Long> {
	    List<Book> findByTitleIgnoreCase(String title);

	    List<Book> findByAuthorIgnoreCase(String author);

	    Book findByISBN(String ISBN);
	}

}
