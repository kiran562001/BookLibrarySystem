package com.cjc.serviece;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cjc.dao.LibraryRepo;
import com.cjc.model.Book;
import com.cjc.model.Library;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class LibraryService {

    private final LibraryRepo libraryRepository;

    @Autowired
    public LibraryService(LibraryRepo libraryRepository) {
        this.libraryRepository = libraryRepository;
    }

    public void addBook(Long libraryId, Book book) {
        Optional<Library> libraryOptional = libraryRepository.findById(libraryId);
        if (libraryOptional.isPresent()) {
            Library library = libraryOptional.get();
            library.getBooks().add(book);
            libraryRepository.save(library);
        } else {
            throw new RuntimeException("Library not found with id: " + libraryId);
        }
    }

    public void removeBook(Long libraryId, String ISBN) {
        Optional<Library> libraryOptional = libraryRepository.findById(libraryId);
        if (libraryOptional.isPresent()) {
            Library library = libraryOptional.get();
            library.getBooks().removeIf(book -> book.getISBN().equals(ISBN));
            libraryRepository.save(library);
        } else {
            throw new RuntimeException("Library not found with id: " + libraryId);
        }
    }

    public List<Book> findBookByTitle(Long libraryId, String title) {
        Optional<Library> libraryOptional = libraryRepository.findById(libraryId);
        if (libraryOptional.isPresent()) {
            Library library = libraryOptional.get();
            return library.getBooks().stream()
                    .filter(book -> book.getTitle().equalsIgnoreCase(title))
                    .collect(Collectors.toList());
        } else {
            throw new RuntimeException("Library not found with id: " + libraryId);
        }
    }

    public List<Book> findBookByAuthor(Long libraryId, String author) {
        Optional<Library> libraryOptional = libraryRepository.findById(libraryId);
        if (libraryOptional.isPresent()) {
            Library library = libraryOptional.get();
            return library.getBooks().stream()
                    .filter(book -> book.getAuthor().equalsIgnoreCase(author))
                    .collect(Collectors.toList());
        } else {
            throw new RuntimeException("Library not found with id: " + libraryId);
        }
    }

    public List<Book> listAllBooks(Long libraryId) {
        Optional<Library> libraryOptional = libraryRepository.findById(libraryId);
        return libraryOptional.map(library -> new ArrayList<>(library.getBooks()))
                .orElseThrow(() -> new RuntimeException("Library not found with id: " + libraryId));
    }

    public List<Book> listAvailableBooks(Long libraryId) {
        Optional<Library> libraryOptional = libraryRepository.findById(libraryId);
        if (libraryOptional.isPresent()) {
            Library library = libraryOptional.get();
            return library.getBooks().stream()
                    .filter(Book::isAvailable)
                    .collect(Collectors.toList());
        } else {
            throw new RuntimeException("Library not found with id: " + libraryId);
        }
    }
}
