package com.cjc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.model.Book;

import com.cjc.serviece.LibraryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/libraries")
public class LibraryController {

    private final LibraryService libraryService;

    @Autowired
    public LibraryController(LibraryService libraryService) {
        this.libraryService = libraryService;
    }

    @PostMapping("/{libraryId}/addBook")
    public void addBook(@PathVariable Long libraryId, @RequestBody Book book) {
        libraryService.addBook(libraryId, book);
    }

    @DeleteMapping("/{libraryId}/removeBook/{ISBN}")
    public void removeBook(@PathVariable Long libraryId, @PathVariable String ISBN) {
        libraryService.removeBook(libraryId, ISBN);
    }

    @GetMapping("/{libraryId}/findBookByTitle/{title}")
    public List<Book> findBookByTitle(@PathVariable Long libraryId, @PathVariable String title) {
        return libraryService.findBookByTitle(libraryId, title);
    }

    @GetMapping("/{libraryId}/findBookByAuthor/{author}")
    public List<Book> findBookByAuthor(@PathVariable Long libraryId, @PathVariable String author) {
        return libraryService.findBookByAuthor(libraryId, author);
    }

    @GetMapping("/{libraryId}/listAllBooks")
    public List<Book> listAllBooks(@PathVariable Long libraryId) {
        return libraryService.listAllBooks(libraryId);
    }

    @GetMapping("/{libraryId}/listAvailableBooks")
    public List<Book> listAvailableBooks(@PathVariable Long libraryId) {
        return libraryService.listAvailableBooks(libraryId);
    }
}
